<!DOCTYPE html>
<html>

<head>
    <link rel="shortcut icon" type="image/png" href="http://gr8synergy.com/subsea/wp-content/uploads/2018/09/gr8-Synergy_Logo-Name-1.png"/>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Subsea | Register</title>

    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

    <link href="<?=base_url()?>assets/css/animate.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/plugins/sweetalert/sweetalert.css" rel="stylesheet">
    <style type="text/css">
        .form-control{
            border-radius: 5px !important;
        }
        .loginscreen.middle-box{
            width: 450px !important;
        }
        .middle-box{
            height: 650px !important;
        }
        label.error{
            font-size: smaller;
            margin-bottom:0px;
        }

    </style>
</head>

<body class="gray-bg">

    <div class="middle-box text-center loginscreen  animated fadeInDown" style=" background: #ffffff;padding: 20px;border-radius: 20px;border: 1px solid #000;box-shadow: 3px 2px;margin-top: -332px !important;">
        <div>
            <img src="http://gr8synergy.com/subsea/wp-content/uploads/2018/11/Logo-New-Tagline-004.png" style="padding-bottom: 0px;height:10%;width:42%;">
            <form method="post" class="m-t" role="form" id="registerUser" action="<?=site_url('Welcome/register_user_details')?>" style="text-align: left !important;">
                <div class="form-group">
                    <input type="text" class="form-control" name="user_firstname" placeholder="First Name" required="">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="user_lastname" placeholder="Last Name" required="">
                </div>
                <div class="form-group">
                    <input type="email" class="form-control" name="user_email" placeholder="Email ID (Username)" required="">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="user_mobile_no" placeholder="Country code followed by mobile number." required="">
                </div>
                <!-- <div class="form-group">
                    <div class="input-group m-b">
                        <span class="input-group-addon"><i class="fa fa fa-birthday-cake"></i></span> 
                        <input type="text" placeholder="Date Of Birth" name="user_DOB" class="form-control datepicker">
                    </div>
                </div> -->
                <div class="col-sm-12 col-lg-12 col-md-12 col-xs-12" style="padding-left: 0px !important;">    
                    <div class="form-group">
                        <div class="col-sm-4 col-lg-4 col-md-4 col-xs-4" style="padding-top: 3% !important;">
                            <label>Nationality</label>
                        </div>
                        <div class="col-sm-8 col-lg-8 col-md-8 col-xs-8">
                            <div class="radio i-checks">
                                <label class="checkbox-inline"> <input type="radio" value="Indian" name="user_nationality" class="division_details_data" checked=""> Indian </label>
                                <label class="checkbox-inline"> <input type="radio" value="other" name="user_nationality" class="division_details_data"> Other</label>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- <div class="form-group">
                    <div class="col-sm-12">
                        <div class="radio i-checks">
                            <label class="checkbox-inline"> <input type="radio" value="1" name="user_division" class="division_details_data" checked=""> Diving </label>
                            <label class="checkbox-inline"> <input type="radio" value="2" name="user_division" class="division_details_data"> Subsea Inst. Engg. </label>
                            <label class="checkbox-inline"> <input type="radio" value="3" name="user_division" class="division_details_data"> Marine </label>
                        </div>
                    </div>
                </div> -->
                <div class="form-group">
                    <select name="user_position_ref_1" class="form-control">
                        <option value="">Select Position I</option>
                        <option value="Diving SME">Diving SME</option>
                        <option value="Diving CSR">Diving CSR</option>
                        <option value="Diving Project Manager">Diving Project Manager</option>
                        <option value="Diving Operations Manager">Diving Operations Manager</option>
                        <option value="Saturation Diving Superintendent (IMCA DIVING SUPERVISOR)">Saturation Diving Superintendent (IMCA DIVING SUPERVISOR)</option>
                        <option value="Subsea Installation Engg SME">Subsea Installation Engg SME</option>
                        <option value="Subsea Installation Engg. CSR">Subsea Installation Engg. CSR</option>
                        <option value="Project Engineer (Subsea : Diving & ROV Ops)">Project Engineer (Subsea : Diving & ROV Ops)</option>
                        <option value="Field Engineer (Subsea : Diving & ROV Ops)">Field Engineer (Subsea : Diving & ROV Ops)</option>
                        <option value="Marine Master - Subsea Projects – SME">Marine Master - Subsea Projects – SME</option>
                        <option value="Marine Master - Subsea Projects – CSR">Marine Master - Subsea Projects – CSR</option>
                        <option value="DP 2 DSV Master - MWS Experience">DP 2 DSV Master - MWS Experience</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="user_position_ref_2" class="form-control">
                        <option value="">Select Position II</option>
                        <option value="Diving SME">Diving SME</option>
                        <option value="Diving CSR">Diving CSR</option>
                        <option value="Diving Project Manager">Diving Project Manager</option>
                        <option value="Diving Operations Manager">Diving Operations Manager</option>
                        <option value="Saturation Diving Superintendent (IMCA DIVING SUPERVISOR)">Saturation Diving Superintendent (IMCA DIVING SUPERVISOR)</option>
                        <option value="Subsea Installation Engg SME">Subsea Installation Engg SME</option>
                        <option value="Subsea Installation Engg. CSR">Subsea Installation Engg. CSR</option>
                        <option value="Project Engineer (Subsea : Diving & ROV Ops)">Project Engineer (Subsea : Diving & ROV Ops)</option>
                        <option value="Field Engineer (Subsea : Diving & ROV Ops)">Field Engineer (Subsea : Diving & ROV Ops)</option>
                        <option value="Marine Master - Subsea Projects – SME">Marine Master - Subsea Projects – SME</option>
                        <option value="Marine Master - Subsea Projects – CSR">Marine Master - Subsea Projects – CSR</option>
                        <option value="DP 2 DSV Master - MWS Experience">DP 2 DSV Master - MWS Experience</option>
                    </select>
                </div>
                <!--<div class="col-sm-12 col-lg-12 col-md-12 col-xs-12" style="padding-left: 0px !important;">    -->
                <!--    <div class="form-group">-->
                <!--        <div class="col-sm-12 col-lg-12 col-md-12 col-xs-12">-->
                <!--            <div class="radio i-checks">-->
                <!--                <label class="checkbox-inline"> <input type="checkbox" name="agree_status" class="" > I have read and understood the <a href="http://gr8synergy.com/subsea/gr8synergy-subsea-privacy-policy/" target="_blank">Terms & Conditions</a> of this wesites.</a> </label>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <div class="col-sm-12 col-lg-12 col-md-12 col-xs-12" style="padding: 0px !important;">    
                    <div class="form-group">
                        <div class="col-sm-12 col-lg-12 col-md-12 col-xs-12" style="padding:0px;">
                            <div class="radio i-checks">
                                <label class="checkbox-inline"> <input type="checkbox" name="agree_status" class="" > I would like to receive the email notification & communication from this website. See our <a href="http://gr8synergy.com/subsea/gr8synergy-subsea-privacy-policy/" target="_blank">Privacy Policy</a>.</label>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- <div class="form-group">
                    <textarea class="form-control" name="user_msg" rows="4">Any Message..</textarea>
                </div> -->
                <!-- <div class="form-group"  id="apply_position">
                    <input class="single-checkbox" type="checkbox" name="user_apply_position[]" value="Diving SME"><b> &nbsp Diving SME</b> &nbsp &nbsp
                    <input class="single-checkbox" type="checkbox" name="user_apply_position[]" value="Diving CSR"><b> &nbsp Diving CSR</b> &nbsp &nbsp
                    <input class="single-checkbox" type="checkbox" name="user_apply_position[]" value="Diving Project  Manager"><b> &nbsp Diving Project  Manager</b> &nbsp &nbsp
                    <input class="single-checkbox" type="checkbox" name="user_apply_position[]" value="Diving Operations  Manager"><b> &nbsp Diving Operations  Manager</b> &nbsp &nbsp
                    <input class="single-checkbox" type="checkbox" name="user_apply_position[]" value="Saturation Diving Superintendent  (IMCA DIVING SUPERVISOR)"><b> &nbsp Saturation Diving Superintendent (IMCA DIVING SUPERVISOR)</b> &nbsp &nbsp
                </div> -->
                <button type="submit" class="btn btn-primary block full-width m-b">Register</button>

                <!-- <a href="#"><small>Forgot password?</small></a> -->
                <!-- <p class="text-muted text-center"><small>Already have an account?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="<?=site_url('Welcome')?>">Login</a> -->
            </form>
            <!-- <p class="m-t"> <small>Inspinia we app framework base on Bootstrap 3 &copy; 2014</small> </p> -->
        </div>
    </div>
    <!-- Mainly scripts -->
    <script src="<?=base_url()?>assets/js/jquery-2.1.1.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
     <!-- Jquery Validate -->
    <script src="<?=base_url()?>assets/js/plugins/validate/jquery.validate.min.js"></script>
    <script src="<?=base_url()?>assets/js/plugins/sweetalert/sweetalert.min.js"></script>
    <script type="text/javascript">

        $( ".datepicker" ).datepicker({
            dateFormat: "yy-mm-dd",
            changeMonth: true,
            changeYear: true,
            yearRange: '1952:2030'
        });

        $(document).ready(function(){  

            <?php if(isset($flash['active']) && $flash['active'] == 12) {?>
                swal({
                    title: "<?=$flash['title']?>",
                    text: "<?=$flash['text']?>",
                    type: "<?=$flash['type']?>",
                    showCancelButton: true,
                    confirmButtonColor: '#81ccee',
                    confirmButtonText: 'Yes',
                    cancelButtonText: "Later",
                    closeOnConfirm: false,
                    closeOnCancel: false
                },
                function(isConfirm){
                    if (isConfirm){
                        window.location.href = '<?php  echo site_url('Welcome/subsea_surve'); ?>';
                    }else{
                        window.location.href = '<?php  echo site_url('Welcome/registration_detials'); ?>';
                    }                
                });
            <?php }if(isset($flash['active']) && $flash['active'] == 1){ ?>
                swal({
                    title: "<?=$flash['title']?>",
                    text: "<?=$flash['text']?>",
                    type: "<?=$flash['type']?>",
                });
            <?php } ?>
        
            $('#registerUser').validate({
                rules:{
                    user_name:{
                        required:true
                    },
                    user_firstname:{
                        required:true
                    },
                    user_lastname:{
                        required:true
                    },
                    user_email:{
                        required:true
                    },
                    user_password:{
                        required:true
                    },
                    'user_apply_position[]':{
                        required:true
                    },
                    CSR_division:{
                        required:true
                    },
                    agree_status:{
                        required:true
                    },
                    user_mobile_no:{
                        required: true,
	                    digits: true,
	                    minlength: 12,
	                    maxlength: 13
                    }
                },
                message:{
                    user_mobile_no:{
	                    minlength: "Country code followed by mobile number.",
	                    maxlength: "Country code followed by mobile number."
                    }
                }
            });

            var limit = 2;
            $(document).on('change','.single-checkbox', function(evt) {
                if($(this).siblings(':checked').length >= limit) {
                   this.checked = false;               
                }
            });        
        })

    </script>
</body>

</html>
