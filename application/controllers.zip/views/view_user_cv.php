<!DOCTYPE html>
<html>

<head>
	<link rel="shortcut icon" type="image/png" href="http://gr8synergy.com/subsea/wp-content/uploads/2018/09/gr8-Synergy_Logo-Name-1.png"/>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Subsea | View User CV</title>

    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=base_url();?>assets/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link href="<?=base_url()?>assets/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/plugins/steps/jquery.steps.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css" rel="stylesheet">
    
    <link href="<?=base_url()?>assets/css/animate.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
    <style type="text/css">
    	#page-wrapper{
    		margin: 0px !important;
    		background-color: #fff;
    	}
    	.ibox{
    		margin-bottom: 0px;
    	}
    	.ibox-title{
    		border-width: 0px 0px 0;
    	}
    </style>
</head>
<body>
    <div id="wrapper">
        <div id="page-wrapper">
	        <div class="row border-bottom">
		        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
			        <div class="navbar-header" style="text-align: center;">
			            <!-- <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a> -->
			            <form role="search" class="navbar-form-custom" action="search_results.html">
			                <div class="form-group">
			                    <img src="http://gr8synergy.com/subsea/wp-content/uploads/2018/11/Logo-New-Tagline-004.png" width="50%">
			                </div>
			            </form>
			        </div>
		            <ul class="nav navbar-top-links navbar-right" style="padding-top: 1%;">
		                <!-- <li>
		                	<a href="http://gr8synergy.com/subsea/"> Home</a>
		                </li>
		                <li class="dropdown" id="config">
                            <a aria-expanded="false" role="button" href="#" class="dropdown-toggle" data-toggle="dropdown">Config <span class="caret"></span></a>
                            <ul role="menu" class="dropdown-menu">
                                <li><a href="http://gr8synergy.com/subsea/about-gr8synergy-subsea/"><b>Vision & Value</b></a></li>
                                <li><a href="http://gr8synergy.com/subsea/gr8synergy-subsea-team/"><b>Team</b></a></li>
                            </ul>
                        </li>
		                <li>
		                	<a href="http://gr8synergy.com/subsea/account/"> Account</a>
		                </li>
		                <li>
		                	<a href="http://gr8synergy.com/subsea/login/"> Login</a>
		                </li> -->
		                <li>
		                	<a href="<?=site_url('Welcome/user_logout')?>"> Logout</a>
		                </li>
		            </ul>
		        </nav>
        	</div>
	        <div class="wrapper wrapper-content animated fadeInRight">
	            <div class="row">
	                <div class="col-lg-12">
		                <div class="ibox float-e-margins">
		                    <div class="ibox-title">
		                        <h5>Register User Details</h5>
		                     </div>
		                 </div>
                        <div class="ibox-content">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover dataTables-example" >
                                    <thead>
                                        <tr>
                                            <th>Sr.No</th>
							                <th>User Name</th>
							                <th>Contact No.</th>
							                <th>DOB</th>
							                <th>Email</th>
							                <th>Nationality</th>
							                <th>Position I</th>
							                <th>Position II</th>
							                <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    	<?php $i=1;foreach ($usr_data as $key) { ?>
                                       	<tr class="gradeX">
							                <td><?=$i++ ?></td>
							                <td><?=$key['user_name']?></td>
							                <td><?=$key['user_mobile_no']?></td>
							                <td><?=$key['user_DOB']?></td>
							                <td><?=$key['user_email']?></td>
							                <td><?=$key['user_nationality']?></td>
							                <td><?=$key['user_position_ref_1']?></td>
							                <td><?=$key['user_position_ref_2']?></td>
							                <td><button class="btn btn-primary btn-xs" data-toggle="modal" id ='<?=$key['user_id']?>' data-target="#viewUserDetails"><i class="fa fa-eye" title="User Details"></i></button></td>
							            </tr>
							            <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
	            </div>
	            <div id="viewUserDetails" class="modal fade" role="dialog">
				  	<div class="modal-dialog" style="width: 90%;">
				    	<!-- Modal content-->
				    	<div class="modal-content">
				      		<div class="modal-header">
				        		<button type="button" class="close" data-dismiss="modal">&times;</button>
				        		<h4 class="modal-title">User CV Details</h4>
				      		</div>
				      		<div class="modal-body">
					        	<div class="row">
					        		<div class="panel blank-panel">
				                        <div class="panel-heading">
				                            <div class="panel-options">
				                                <ul class="nav nav-tabs">
				                                    <li class="active"><a data-toggle="tab" href="#tab-1">Information Personal</a></li>
				                                    <li class=""><a data-toggle="tab" href="#tab-2">Information Next to Kin</a></li>
				                                </ul>
				                            </div>
				                        </div>
				                        <div class="panel-body">
				                            <div class="tab-content">
				                                <div id="tab-1" class="tab-pane active">
				                                    <form>
				                                    	<div class="form-group">
				                                    		<label class="control-label col-sm-2">Name</label>
				                                    		<label class="control-label col-sm-1">:</label>
				                                    		<div class="col-sm-3">
				                                    			<p class="form-control-static" id="view_name"></p>
				                                    		</div>
				                                    		<label class="control-label col-sm-2">Date Of Birth</label>
				                                    		<label class="control-label col-sm-1">:</label>
				                                    		<div class="col-sm-3">
				                                    			<p class="form-control-static" id="view_DOB"></p>
				                                    		</div>
				                                    	</div>
				                                    	<div class="form-group">
				                                    		<label class="control-label col-sm-2">Passport No.</label>
				                                    		<label class="control-label col-sm-1">:</label>
				                                    		<div class="col-sm-3">
				                                    			<p class="form-control-static" id="view_pass"></p>
				                                    		</div>
				                                    		<label class="control-label col-sm-2">PP Issue Authority</label>
				                                    		<label class="control-label col-sm-1">:</label>
				                                    		<div class="col-sm-3">
				                                    			<p class="form-control-static" id="view_issue_authority"></p>
				                                    		</div>
				                                    	</div>
				                                    	<div class="form-group">
				                                    		<label class="control-label col-sm-2">Passport Validity</label>
				                                    		<label class="control-label col-sm-1">:</label>
				                                    		<div class="col-sm-3">
				                                    			<p class="form-control-static" id="view_pass_validity"></p>
				                                    		</div>
				                                    		<label class="control-label col-sm-2">Mobile No.</label>
				                                    		<label class="control-label col-sm-1">:</label>
				                                    		<div class="col-sm-3">
				                                    			<p class="form-control-static" id="view_mobile_no"></p>
				                                    		</div>
				                                    	</div>
				                                    	<div class="form-group">
				                                    		<label class="control-label col-sm-2">WhatsApp No.</label>
				                                    		<label class="control-label col-sm-1">:</label>
				                                    		<div class="col-sm-3">
				                                    			<p class="form-control-static" id="view_whatsapp_no"></p>
				                                    		</div>
				                                    		<label class="control-label col-sm-2">Are you Director in a company</label>
				                                    		<label class="control-label col-sm-1">:</label>
				                                    		<div class="col-sm-3">
				                                    			<p class="form-control-static" id="view_director"></p>
				                                    		</div>
				                                    	</div>
				                                    	<div class="form-group">
				                                    		<label class="control-label col-sm-2">Company Name</label>
				                                    		<label class="control-label col-sm-1">:</label>
				                                    		<div class="col-sm-3">
				                                    			<p class="form-control-static" id="view_company"></p>
				                                    		</div>
				                                    		<!-- <label class="control-label col-sm-2"></label>
				                                    		<label class="control-label col-sm-1">:</label>
				                                    		<label class="control-label col-sm-3"></label> -->
				                                    	</div>
				                                    </form>
				                                </div>
				                                <div id="tab-2" class="tab-pane">
				                                    <form>
				                                    	<div class="form-group">
				                                    		<label class="control-label col-sm-2">Next to Kin - Name</label>
				                                    		<label class="control-label col-sm-1">:</label>
				                                    		<div class="col-sm-3">
				                                    			<p class="form-control-static" id="view_kin_name"></p>
				                                    		</div>
				                                    		<label class="control-label col-sm-2">Relationship Kin</label>
				                                    		<label class="control-label col-sm-1">:</label>
				                                    		<div class="col-sm-3">
				                                    			<p class="form-control-static" id="view_kin_relationship"></p>
				                                    		</div>
				                                    	</div><br>
				                                    	<div class="form-group">
				                                    		<label class="control-label col-sm-2">Next of Kin - Email</label>
				                                    		<label class="control-label col-sm-1">:</label>
				                                    		<div class="col-sm-3">
				                                    			<p class="form-control-static" id="view_kin_email"></p>
				                                    		</div>
				                                    		<label class="control-label col-sm-2">Next of Kin Mobile No</label>
				                                    		<label class="control-label col-sm-1">:</label>
				                                    		<div class="col-sm-3">
				                                    			<p class="form-control-static" id="view_kin_mobile"></p>
				                                    		</div>
				                                    	</div>				                                    	
				                                    </form>
				                                </div>
				                            </div>
				                        </div>
				                    </div>
					        	</div>		
					      	</div>
					      	<div class="modal-footer">
					        	<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					      	</div>
				    	</div>
				  	</div>
				</div>
	        </div>
       </div>
   	</div>

    <!-- Mainly scripts -->
    <script src="<?=base_url()?>assets/js/jquery-2.1.1.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
    <script src="<?=base_url()?>assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?=base_url()?>assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?=base_url()?>assets/js/inspinia.js"></script>
    <script src="<?=base_url()?>assets/js/plugins/pace/pace.min.js"></script>

    <!-- Data Tables -->
    <script src="<?=base_url()?>assets/js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="<?=base_url()?>assets/js/plugins/dataTables/dataTables.bootstrap.js"></script>
    <!-- <script src="<?=base_url()?>assets/js/plugins/dataTables/dataTables.responsive.js"></script>
    <script src="<?=base_url()?>assets/js/plugins/dataTables/dataTables.tableTools.min.js"></script> -->

    <!-- Steps -->
    <script src="<?=base_url()?>assets/js/plugins/staps/jquery.steps.js"></script>
    <script src="<?=base_url()?>assets/js/plugins/iCheck/icheck.min.js"></script>

    <!-- Jquery Validate -->
    <script src="<?=base_url()?>assets/js/plugins/validate/jquery.validate.min.js"></script>

    <script type="text/javascript">
    	$(document).ready(function() {
            $('.dataTables-example').dataTable({
                responsive: true,
                "dom": 'T<"clear">lfrtip',
                 buttons: [
			        'copy', 'excel', 'pdf', 'csv'
			    ]
                
            });

            $('#viewUserDetails').on('show.bs.modal', function(e) {
                var user_id = e.relatedTarget.id;
                $.post('<?=site_url('Welcome/user_history_details')?>',{user_id:user_id},function(data){
                	console.log(data);
                	$('#view_name').text(data[0].user_name);
                	$('#view_DOB').text(data[0].user_DOB);
                	$('#view_pass').text(data[0].user_passport_no);
                	$('#view_issue_authority').text(data[0].user_pp_issue_authority);
                	$('#view_pass_validity').text(data[0].user_passport_validaty);
                	$('#view_mobile_no').text(data[0].user_mobile_no);
                	$('#view_whatsapp_no').text(data[0].user_whatsapp_no);
                	$('#view_director').text(data[0].user_company_director);
                	$('#view_company').text(data[0].user_company_name);
                	$('#view_kin_name').text(data[0].kin_name);
                	$('#view_kin_relationship').text(data[0].kin_relationship);
                	$('#view_kin_email').text(data[0].kin_email);
                	$('#view_kin_mobile').text(data[0].kin_mobile_no);
                },'json');
            });
        });
    </script>
    
</body>

</html>
