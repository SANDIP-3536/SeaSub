<!DOCTYPE html>
<html>

<head>
	<link rel="shortcut icon" type="image/png" href="http://gr8synergy.com/subsea/wp-content/uploads/2018/09/gr8-Synergy_Logo-Name-1.png"/>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Subsea | Upload CV</title>

    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link href="<?=base_url()?>assets/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/plugins/steps/jquery.steps.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/plugins/chosen/chosen.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="<?=base_url()?>assets/css/animate.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
    <style type="text/css">
    	#page-wrapper{
    		margin: 0px !important;
    		background-color: #fff;
    	}
    	.wizard > .content{
    		background:#f5feff !important ;
    	}
    	.wizard > .content > .body input.error{
    		background: rgb(251, 227, 228);
		    border: 1px solid #fbc2c4;
		    color: #8a1f11;
    	}
    	.wizard > .content > .body label.error{
    		display: none !important;
    	}
    	.wizard > .steps .current a, .wizard > .steps .current a:hover, .wizard > .steps .current a:active{
    		font-size: x-small;
    	}
    	.wizard > .steps a, .wizard > .steps a:hover, .wizard > .steps a:active{
    		font-size: x-small;
    	}
    	.wizard > .steps .disabled a, .wizard > .steps .disabled a:hover, .wizard > .steps .disabled a:active{
    		font-size: x-small;
    	}
    	.wizard > .content > .body{
    		position: initial !important;
    		width: 100% !important;
    	}
    	.chosen-container{
    		width: 100% !important;
    		position: initial !important;
    	}
    </style>
</head>
<body>
    <div id="wrapper">
        <div id="page-wrapper">
	        <div class="row border-bottom">
		        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
			        <div class="navbar-header" style="text-align: center;">
			            <!-- <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a> -->
			            <form role="search" class="navbar-form-custom" action="search_results.html">
			                <div class="form-group">
			                    <img src="http://gr8synergy.com/subsea/wp-content/uploads/2018/11/Logo-New-Tagline-004.png" width="50%">
			                </div>
			            </form>
			        </div>
		            <ul class="nav navbar-top-links navbar-right" style="padding-top: 1%;">
		                <li>
		                	<a href="http://gr8synergy.com/subsea/"> Home</a>
		                </li>
		                <!-- <li class="dropdown" id="config">
                            <a aria-expanded="false" role="button" href="#" class="dropdown-toggle" data-toggle="dropdown">Config <span class="caret"></span></a>
                            <ul role="menu" class="dropdown-menu">
                                <li><a href="http://gr8synergy.com/subsea/about-gr8synergy-subsea/"><b>Vision & Value</b></a></li>
                                <li><a href="http://gr8synergy.com/subsea/gr8synergy-subsea-team/"><b>Team</b></a></li>
                            </ul>
                        </li>
		                <li>
		                	<a href="http://gr8synergy.com/subsea/account/"> Account</a>
		                </li>
		                <li>
		                	<a href="http://gr8synergy.com/subsea/login/"> Login</a>
		                </li>
		                <li>
		                	<a href="<?=site_url('Welcome/user_logout')?>"> Logout</a>
		                </li> -->
		            </ul>
		        </nav>
        	</div>
	        <div class="wrapper wrapper-content animated fadeInRight">
	            <div class="row">
	                <div class="col-lg-10 col-lg-offset-1">
	                    <div class="ibox-content" style="border: 1px solid #e7eaec;">
	                    	<form method="post" class="form-horizontal" enctype="multipart/form-data" id="form" action="<?=site_url('Welcome/register_surve')?>">
	                            <fieldset>
	                               	<div class="row">
	                               		<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
	                               			<div class="ibox float-e-margins" style="border: 2px solid #e7eaec;border-radius: 5px;">
		                                        <div class="ibox-title" style="border:none;background: #F5F5F5;">
												    <h5>gr8synergy Subsea Survey Questionnaire</h5>
												</div>
												<div class="ibox-content" style="background: #f5feff;">
													<div class="row" style="padding-right: 2%;padding-left: 2%;">											 	
					                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 hidden">
																<div class="form-group">
																	<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																		<label></label>
							                                            <input type="text" placeholder="" name="surve_user_id" class="form-control" value="<?php echo $user_id;?>">
							                                        </div>
																</div>
					                                        </div>
					                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																<div class="form-group">
																	<div class="col-sm-9 col-lg-9 col-md-9 col-xs-9" style="padding-top: 2%;">
																		<label>Should there be an age limit on Diving systems used for Offshore Commercial Diving ?</label> 
																	</div>
																	<div class="col-sm-3 col-lg-3 col-md-3 col-xs-3">
						                                            	<div class="radio i-checks">
							                                            	<label class="checkbox-inline"> <input type="radio" class="age_limit" value="yes" name="surve_age_limit"> <i></i> Yes (Agree)</label>
							                                            	<label class="checkbox-inline"> <input type="radio" class="age_limit" value="no" name="surve_age_limit"> <i></i>Disagree </label>
							                                            </div>
							                                        </div>
																</div>
					                                        </div>
					                                        <div class="col-sm-12 hidden" id="surve_age_details">
																<div class="form-group">
																	<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																		<label>Please Enter the age limit on Diving systems used for Offshore Commercial Diving</label>
							                                            <input type="text" placeholder="Please Enter the age limit on Diving systems used for Offshore Commercial Diving" name="surve_age_details" class="form-control">
							                                        </div>
																</div>
					                                        </div>
					                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12" id="div_eng_data">
																<div class="form-group">
																	<div class="col-sm-9 col-lg-9 col-md-9 col-xs-9" style="padding-top: 2%;">
																		<label>Should the Diving Systems used for Commercial Diving be designed,built and certified to a recognised Classification Society that has clear rules for the same  ?</label> 
																	</div>
																	<div class="col-sm-3 col-lg-3 col-md-3 col-xs-3">
						                                            	<div class="radio i-checks">
							                                            	<label class="checkbox-inline"> <input type="radio" value="yes" name="surve_comm_diving"> <i></i> Yes (Agree) </label>
							                                            	<label class="checkbox-inline"> <input type="radio" value="no" name="surve_comm_diving"> <i></i>Disagree </label>
							                                            </div>
							                                        </div>
																</div>
					                                        </div>
					                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																<div class="form-group">
																	<div class="col-sm-9 col-lg-9 col-md-9 col-xs-9" style="padding-top: 2%;">
																		<label>Should there be an age limit on Diving Support Vessel for Offshore Commercial Diving ?<br>Both Categories Purpose Build as DP2 DSV by Class or a DP2 Vessel of Opportunity with a Modular Diving System installed.</label> 
																	</div>
																	<div class="col-sm-3 col-lg-3 col-md-3 col-xs-3">
						                                            	<div class="radio i-checks">
							                                            	<label class="checkbox-inline"> <input type="radio" class="age_limit_diving" value="yes" name="surve_age_limit_diving"> <i></i> Yes (Agree) </label>
							                                            	<label class="checkbox-inline"> <input type="radio" class="age_limit_diving" value="no" name="surve_age_limit_diving"> <i></i>Disagree </label>
							                                            </div>
							                                        </div>
																</div>
					                                        </div>
					                                        <div class="col-sm-12 hidden" id="surve_age_diving_details">
																<div class="form-group">
																	<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																		<label>Please Enter the age limit on Diving Support Vessel for Offshore Commercial Diving</label>
							                                            <input type="text" placeholder="Please Enter the age limit on Diving Support Vessel for Offshore Commercial Diving" name="surve_age_diving_details" class="form-control">
							                                        </div>
																</div>
					                                        </div>
					                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																<div class="form-group">
																	<div class="col-sm-9 col-lg-9 col-md-9 col-xs-9" style="padding-top: 2%;">
																		<label> Would you agree DP2 Vessel's designed,built and certified by a recognised Classification Society with a Class Notation as DSV are better equipped to handle subsea construction involving divers are far better than any DP2 Vessel of Opportunity with a modular diving system installed on it ?</label> 
																	</div>
																	<div class="col-sm-3 col-lg-3 col-md-3 col-xs-3">
						                                            	<div class="radio i-checks">
							                                            	<label class="checkbox-inline"> <input type="radio" value="yes" name="surve_diving_support_vessel"> <i></i> Yes (Agree) </label>
							                                            	<label class="checkbox-inline"> <input type="radio" value="no" name="surve_diving_support_vessel"> <i></i>Disagree </label>
							                                            </div>
							                                        </div>
																</div>
					                                        </div>
					                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																<div class="form-group">
																	<div class="col-sm-9 col-lg-9 col-md-9 col-xs-9" style="padding-top: 2%;">
																		<label>Would you agree inconsistent pay scale and delayes salary disbursement is an issue that plagues Indian Diving Industry and negatively impacts the outcome of Subsea Construction Projects?<br>Is it a  DEMOTIVATING FACTOR ?</label> 
																	</div>
																	<div class="col-sm-3 col-lg-3 col-md-3 col-xs-3">
						                                            	<div class="radio i-checks">
							                                            	<label class="checkbox-inline"> <input type="radio" value="yes" name="surve_incosistent_pay_scale"> <i></i> Yes (Agree) </label>
							                                            	<label class="checkbox-inline"> <input type="radio" value="no" name="surve_incosistent_pay_scale"> <i></i>Disagree </label>
							                                            </div>
							                                        </div>
																</div>
					                                        </div>
					                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																<div class="form-group">
																	<div class="col-sm-9 col-lg-9 col-md-9 col-xs-9" style="padding-top: 2%;">
																		<label>Would you agree that Divers Pay should should be secured and not be linked back to back payment from Client based on Project Milestones ?<br>
Diver's work to the best of their ability in the harshest of the environment to ensure the Nation's subsea infrastructure for Oil and Gas production is operational 24x7 (365 days) , however due to many other reasons as mentioned below Subsea Construction Projects are derailed and the majority of the Financial brunt is borne by the Divers. <br>
PRE AWARD (Defining the SOW and Diving Contracto Evaluation) : No involvement of experienced and competent Diving Subject Matter Experts to develop a clear SOW and Contractor evaluation criteria, lack of effective pre-engineering / unverified engineering data / lack off,  inadequate technical,operational and HSE evaluation of Diving Contractors execution strategy and plan to name a few factors.<br>
POST AWARD (Execution Strategy and Operations) : Inherent Limitations of Diving and Marine Spread that were not highlighted, installtion aid inadequatness / limitation, ineffectient methodology, inexperienced Dive Teams, no contingency plan, unpredictable weather, limited / missed weather window, unavailability of workite due to SIMOPSto name a few factors.</label> 
					                                            	</div>
					                                            	<div class="col-sm-3 col-lg-3 col-md-3 col-xs-3">
					                                            		<div class="radio i-checks">
							                                            	<label class="checkbox-inline"> <input type="radio" value="yes" name="surve_diver_pay"> <i></i> Yes (Agree) </label>
							                                            	<label class="checkbox-inline"> <input type="radio" value="no" name="surve_diver_pay"> <i></i>Disagree </label>
							                                            </div>
							                                        </div>
																</div>
					                                        </div>
					                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																<div class="form-group">
																	<div class="col-sm-9 col-lg-9 col-md-9 col-xs-9" style="padding-top: 2%;">
																		<label>As per the RERA Act (Real Estate Regulatory Authority) , the promoter has to maintain a 'separate account' for every project undertaken wherein 70 percent of the money received from the buyers of the flat shall be deposited into an escrow to protect the interest of the Customer's.<br>
Would you agree that a similar mechanism in Oil and Gas Subsea Construction project involving Divers would be effective to ensure Divers Salary is not compromised due to Diving Contractors Not meeting Contractual milestone due to various other reasons as specified above in Point No. 8</label> 
					                                            	</div>
					                                            	<div class="col-sm-3 col-lg-3 col-md-3 col-xs-3">
					                                            		<div class="radio i-checks">
							                                            	<label class="checkbox-inline"> <input type="radio" value="yes" name="surve_RERA_act"> <i></i> Yes (Agree) </label>
							                                            	<label class="checkbox-inline"> <input type="radio" value="no" name="surve_RERA_act"> <i></i>Disagree </label>
							                                            </div>
							                                        </div>
																</div>
					                                        </div>
					                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																<div class="form-group">
																	<div class="col-sm-9 col-lg-9 col-md-9 col-xs-9" style="padding-top: 2%;">
																		<label>Would you agree that all of the above factors when effectively managed would positively affect your safety, your offshore working conditions, your individual health, your psychological well-being & happiness and as an resut improve  your performance as a Professional involved in Subsea Construction Projects by reducing the stress whilst you undertake a highly risky Operations at sea and is more than LIKELY to improve the overall Project Outcome ?</label> 
					                                            	</div>
					                                            	<div class="col-sm-3 col-lg-3 col-md-3 col-xs-3">
						                                            	<div class="radio i-checks">
							                                            	<label class="checkbox-inline"> <input type="radio" value="yes" name="surve_agree_factor"> <i></i> Yes (Agree) </label>
							                                            	<label class="checkbox-inline"> <input type="radio" value="no" name="surve_agree_factor"> <i></i>Disagree </label>
							                                            </div>
							                                        </div>
																</div>
					                                        </div>		
					                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																<div class="form-group">
																	<div class="col-sm-9 col-lg-9 col-md-9 col-xs-9" style="padding-top: 2%;">
																		<label>Would you agree  that Professionals of INDIAN nationality who are have more than 30 years of experience in Offshore Diving Operations, having credible experience of major Subsea Construction Projects with global Oil and Gas Operators should be involved in defining the SOW and Diving Contractor evaluation for all subsea construction as it will help up the standard of the INDIAN Diving Industry ?<br>Would you agree that the Clients should engage such Individuals ?<br>* Indian National would be more sympathetic to the LOCAL challenges and are more likely to take ownership in Process Improvement.</label> 
					                                            	</div>
					                                            	<div class="col-sm-3 col-lg-3 col-md-3 col-xs-3">
						                                            	<div class="radio i-checks">
							                                            	<label class="checkbox-inline"> <input type="radio" value="yes" name="surve_indian_nationality"> <i></i> Yes (Agree) </label>
							                                            	<label class="checkbox-inline"> <input type="radio" value="no" name="surve_indian_nationality"> <i></i>Disagree </label>
							                                            </div>
							                                        </div>
																</div>
					                                        </div>		
					                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																<div class="form-group">
																	<div class="col-sm-9 col-lg-9 col-md-9 col-xs-9" style="padding-top: 2%;">
																		<label>Saturation Diving Operations.<br>Would you agree that  a Hyperbaric Reception Facility should be set up , manned and operational at all times when Saturation Diving Operations are being undertaken in an oil field in line with IMCA Guidance / OGP recommendations ?</label> 
					                                            	</div>
					                                            	<div class="col-sm-3 col-lg-3 col-md-3 col-xs-3">
						                                            	<div class="radio i-checks">
							                                            	<label class="checkbox-inline"> <input type="radio" value="yes" name="surve_SDO_IMCA_OGP"> <i></i> Yes (Agree) </label>
							                                            	<label class="checkbox-inline"> <input type="radio" value="no" name="surve_SDO_IMCA_OGP"> <i></i>Disagree </label>
							                                            </div>
							                                        </div>
																</div>
					                                        </div>	
					                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																<div class="form-group">
																	<div class="col-sm-9 col-lg-9 col-md-9 col-xs-9" style="padding-top: 2%;">
																		<label>Do you think having National Regulations for Offshore / Commercial Diving will impact the outcome of Offshore Subsea Construction Projects ?</label> 
																	</div>
																	<div class="col-sm-3 col-lg-3 col-md-3 col-xs-3">
						                                            	<div class="radio i-checks">
							                                            	<label class="checkbox-inline"><input type="radio" value="yes" name="surve_national_regulation" > <i></i> Yes (Agree) </label>
							                                            	<label class="checkbox-inline"><input type="radio" value="no" name="surve_national_regulation" > <i></i>Disagree </label>
							                                            </div>
							                                        </div>
																</div>
					                                        </div>
					                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																<div class="form-group">
																	<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																		<label>Do you think the UK ACoP for Commercial Diving or the Norwegian Petroleum Directorate Diving regulations is better suited for India?</label>
							                                            <select name="surve_UK_ACoP" class="form-control" >
							                                            	<option value="">Please Select</option>
							                                            	<option value="UK ACoP for Commerial Diving">UK ACoP for Commerial Diving</option>
							                                            	<option value="Norwegian Petroleum Directorate Diving regulations ?">Norwegian Petroleum Directorate Diving regulations ?</option>
							                                            </select>
							                                        </div>
																</div>
					                                        </div>	
					                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																<div class="form-group">
																	<div class="col-sm-9 col-lg-9 col-md-9 col-xs-9" style="padding-top: 2%;">
																		<label>Would you agree that this survey questionnaire is  UNBIASED  with the clear objective to identify the challenges and  areas of improvement for the  INDIAN Diving Industry that would positively impact the outcome of subsea construction projects ?</label> 
					                                            	</div>
					                                            	<div class="col-sm-3 col-lg-3 col-md-3 col-xs-3">
						                                            	<div class="radio i-checks">
							                                            	<label class="checkbox-inline"> <input type="radio" value="yes" name="surve_questionnaire"> <i></i> Yes (Agree) </label>
							                                            	<label class="checkbox-inline"> <input type="radio" value="no" name="surve_questionnaire"> <i></i>Disagree </label>
							                                            </div>
							                                        </div>
																</div>
					                                        </div>		
					                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
																<div class="form-group">
																	<center><button class="btn btn-primary" type="submit">Submit</button></center>
																</div>
					                                        </div>					                                        
					                                    </div>
				                                    </div>
				                                </div>
				                            </div>
	                               		</div>
	                               	</div>
	                            </fieldset>
	                        </form>
	                    </div>
	                </div>
	            </div>
	        </div>
       </div>
   	</div>

    <!-- Mainly scripts -->
    <script src="<?=base_url()?>assets/js/jquery-2.1.1.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
    <script src="<?=base_url()?>assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?=base_url()?>assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?=base_url()?>assets/js/inspinia.js"></script>
    <script src="<?=base_url()?>assets/js/plugins/pace/pace.min.js"></script>

    <!-- Chosen -->
    <script src="<?=base_url()?>assets/js/plugins/chosen/chosen.jquery.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>

	<!-- Country JS -->
    <script type= "text/javascript" src ="<?=base_url()?>assets/js/countries.js"></script>

    <!-- Steps -->
    <script src="<?=base_url()?>assets/js/plugins/staps/jquery.steps.js"></script>
    <script src="<?=base_url()?>assets/js/plugins/iCheck/icheck.min.js"></script>

    <!-- Jquery Validate -->
    <script src="<?=base_url()?>assets/js/plugins/validate/jquery.validate.min.js"></script>

    <script type="text/javascript">

        // Datepicker Function
        $(document).on('change','.age_limit',function(){			
			var age = $(this).val();
			switch(age){
				case 'yes':
					$('#surve_age_details').removeClass();
					$('#surve_age_details').addClass('col-sm-12');
					break;
				case 'no':
					$('#surve_age_details').removeClass();
					$('#surve_age_details').addClass('col-sm-12 hidden');
					break;
			}
		});

		$(document).on('change','.age_limit_diving',function(){			
			var age = $(this).val();
			switch(age){
				case 'yes':
					$('#surve_age_diving_details').removeClass();
					$('#surve_age_diving_details').addClass('col-sm-12');
					break;
				case 'no':
					$('#surve_age_diving_details').removeClass();
					$('#surve_age_diving_details').addClass('col-sm-12 hidden');
					break;
			}
		});
		$( ".datepicker" ).datepicker({
			dateFormat: "yy-mm-dd",
		    changeMonth: true,
		    changeYear: true,
      		yearRange: '1952:2030'
		});
		$( ".datepicker_expiry" ).datepicker({
			dateFormat: "yy-mm-dd",
		    changeMonth: true,
		    changeYear: true,
      		yearRange: (new Date).getFullYear()+':2030'
		});

		$('.scope_select').select2({
			placeholder: ""
		});

		
    </script>

</body>

</html>